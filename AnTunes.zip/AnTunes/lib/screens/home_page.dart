/*
 *     Copyright (C) 2026 Valeri Gokadze
 *
 *     Musify is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Musify is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 *
 *     For more information about Musify, including how to contribute,
 *     please visit: https://github.com/gokadzev/Musify
 */

import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:antunes/constants/app_constants.dart';
import 'package:antunes/extensions/l10n.dart';
import 'package:antunes/main.dart';
import 'package:antunes/services/common_services.dart';
import 'package:antunes/services/playlists_manager.dart';
import 'package:antunes/services/settings_manager.dart';
import 'package:antunes/utilities/app_utils.dart';
import 'package:antunes/utilities/async_loader.dart';
import 'package:antunes/widgets/announcement_box.dart';
import 'package:antunes/widgets/mini_player_bottom_space.dart';
import 'package:antunes/widgets/playlist_cube.dart';
import 'package:antunes/widgets/section_header.dart';
import 'package:antunes/widgets/song_bar.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final playlistHeight = MediaQuery.sizeOf(context).height * 0.25 / 1.1;
    return Scaffold(
      appBar: AppBar(title: const Text('AnTunes.')),
      body: SingleChildScrollView(
        padding: commonSingleChildScrollViewPadding,
        child: Column(
          children: [
            ValueListenableBuilder<String?>(
              valueListenable: announcementURL,
              builder: (_, _url, __) {
                if (_url == null) return const SizedBox.shrink();
                final isSponsorshipAnnouncement = isSponsorshipAnnouncementUrl(
                  _url,
                );
                final _message = isSponsorshipAnnouncement
                    ? context.l10n!.sponsorProject
                    : context.l10n!.newAnnouncement;
                final _icon = isSponsorshipAnnouncement
                    ? FluentIcons.heart_24_filled
                    : FluentIcons.megaphone_24_filled;

                return AnnouncementBox(
                  message: _message,
                  url: _url,
                  icon: _icon,
                  onDismiss: () async {
                    announcementURL.value = null;
                  },
                );
              },
            ),
            _buildSuggestedPlaylists(playlistHeight),
            _buildSuggestedPlaylists(playlistHeight, showOnlyLiked: true),
            _buildMostPlayedSection(),
            _buildRecommendedSongsSection(),
            const MiniPlayerBottomSpace(),
          ],
        ),
      ),
    );
  }

  Widget _buildSuggestedPlaylists(
    double playlistHeight, {
    bool showOnlyLiked = false,
  }) {
    if (showOnlyLiked) {
      return ValueListenableBuilder<List<Map>>(
        valueListenable: userLikedPlaylists,
        builder: (_, likedPlaylists, __) => _buildSuggestedPlaylistsSection(
          playlistHeight,
          likedPlaylists.take(recommendedCubesNumber).toList(),
          showOnlyLiked: true,
        ),
      );
    }

    return AsyncLoader<List<dynamic>>(
      future: getPlaylists(playlistsNum: recommendedCubesNumber),
      builder: (context, playlists) => _buildSuggestedPlaylistsSection(
        playlistHeight,
        playlists,
      ),
    );
  }

  Widget _buildSuggestedPlaylistsSection(
    double playlistHeight,
    List<dynamic> playlists, {
    bool showOnlyLiked = false,
  }) {
    if (playlists.isEmpty) return const SizedBox.shrink();

    final sectionTitle = showOnlyLiked
        ? context.l10n!.backToFavorites
        : context.l10n!.suggestedPlaylists;
    final itemsNumber = playlists.length.clamp(0, recommendedCubesNumber);
    final isLargeScreen = MediaQuery.of(context).size.width > 480;

    return Column(
      children: [
        SectionHeader(
          title: sectionTitle,
          icon: showOnlyLiked
              ? FluentIcons.heart_24_filled
              : FluentIcons.list_24_filled,
        ),
        ConstrainedBox(
          constraints: BoxConstraints(maxHeight: playlistHeight),
          child: isLargeScreen
              ? _buildHorizontalList(playlists, itemsNumber, playlistHeight)
              : _buildCarouselView(playlists, itemsNumber, playlistHeight),
        ),
      ],
    );
  }

  Widget _buildHorizontalList(
    List<dynamic> playlists,
    int itemCount,
    double height,
  ) {
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: itemCount,
      itemBuilder: (context, index) {
        final playlist = playlists[index];
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: GestureDetector(
            onTap: () => context.push('/home/playlist/${playlist['ytid']}'),
            child: PlaylistCube(playlist, size: height),
          ),
        );
      },
    );
  }

  Widget _buildCarouselView(
    List<dynamic> playlists,
    int itemCount,
    double height,
  ) {
    return CarouselView.weighted(
      flexWeights: const <int>[3, 2, 1],
      itemSnapping: true,
      onTap: (index) =>
          context.push('/home/playlist/${playlists[index]['ytid']}'),
      children: List.generate(itemCount, (index) {
        return PlaylistCube(playlists[index], size: height * 2);
      }),
    );
  }

  Widget _buildRecommendedSongsSection() {
    return ValueListenableBuilder<bool>(
      valueListenable: externalRecommendations,
      builder: (_, recommendations, __) {
        return AsyncLoader<List<dynamic>>(
          future: getRecommendedSongs(),

          builder: (context, data) {
            if (data.isEmpty) return const SizedBox.shrink();
            return _buildRecommendedForYouSection(context, data);
          },
        );
      },
    );
  }

  Widget _buildMostPlayedSection() {
    final sectionTitle = context.l10n!.mostPlayed;

    return ValueListenableBuilder<List>(
      valueListenable: userRecentlyPlayed,
      builder: (_, __, ___) {
        return ValueListenableBuilder<int>(
          valueListenable: recentlyPlayedVersion,
          builder: (_, __, ___) {
            final mostPlayedSongs = getMostPlayed(limit: 5);
            if (mostPlayedSongs.isEmpty) {
              return const SizedBox.shrink();
            }

            return Column(
              children: [
                SectionHeader(
                  title: sectionTitle,
                  icon: FluentIcons.music_note_2_24_filled,
                  actionButton: IconButton(
                    onPressed: () async {
                      await audioHandler.playPlaylistSong(
                        playlist: {
                          'title': sectionTitle,
                          'list': mostPlayedSongs,
                        },
                        songIndex: 0,
                      );
                    },
                    icon: Icon(
                      FluentIcons.play_circle_24_filled,
                      color: Theme.of(context).colorScheme.primary,
                      size: 30,
                    ),
                  ),
                ),
                ListView.builder(
                  shrinkWrap: true,
                  physics: const BouncingScrollPhysics(),
                  itemCount: mostPlayedSongs.length,
                  padding: commonListViewBottomPadding,
                  itemBuilder: (context, index) {
                    final borderRadius = getItemBorderRadius(
                      index,
                      mostPlayedSongs.length,
                    );
                    final song = mostPlayedSongs[index];

                    return RepaintBoundary(
                      key: listItemKey('home_most_played', index, song),
                      child: SongBar(
                        song,
                        true,
                        borderRadius: borderRadius,
                        showPlayTime: true,
                      ),
                    );
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildRecommendedForYouSection(
    BuildContext context,
    List<dynamic> data,
  ) {
    final recommendedTitle = context.l10n!.recommendedForYou;

    return Column(
      children: [
        SectionHeader(
          title: recommendedTitle,
          icon: FluentIcons.sparkle_24_filled,
          actionButton: IconButton(
            onPressed: () async {
              await audioHandler.playPlaylistSong(
                playlist: {'title': recommendedTitle, 'list': data},
                songIndex: 0,
              );
            },
            icon: Icon(
              FluentIcons.play_circle_24_filled,
              color: Theme.of(context).colorScheme.primary,
              size: 30,
            ),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const BouncingScrollPhysics(),
          itemCount: data.length,
          padding: commonListViewBottomPadding,
          itemBuilder: (context, index) {
            final borderRadius = getItemBorderRadius(index, data.length);
            return RepaintBoundary(
              key: listItemKey('home_recommended', index, data[index]),
              child: SongBar(data[index], true, borderRadius: borderRadius),
            );
          },
        ),
      ],
    );
  }
}
