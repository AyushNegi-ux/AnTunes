/*
 *     Copyright (C) 2026 Valeri Gokadze
 *
 *     Musify is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Musify is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 *
 *     For more information about Musify, including how to contribute,
 *     please visit: https://github.com/gokadzev/Musify
 */

import 'dart:async';

import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:antunes/constants/app_constants.dart';
import 'package:antunes/extensions/l10n.dart';
import 'package:antunes/main.dart';
import 'package:antunes/services/common_services.dart';
import 'package:antunes/services/data_manager.dart';
import 'package:antunes/services/playlist_download_service.dart';
import 'package:antunes/services/playlist_sharing.dart';
import 'package:antunes/services/playlists_manager.dart';
import 'package:antunes/services/settings_manager.dart';
import 'package:antunes/utilities/app_utils.dart';
import 'package:antunes/utilities/flutter_toast.dart';
import 'package:antunes/utilities/offline_playlist_dialogs.dart';
import 'package:antunes/utilities/playlist_dialogs.dart';
import 'package:antunes/utilities/playlist_utils.dart';
import 'package:antunes/utilities/song_filtering.dart';
import 'package:antunes/utilities/sort_utils.dart';
import 'package:antunes/widgets/edit_playlist_dialog.dart';
import 'package:antunes/widgets/mini_player_bottom_space.dart';
import 'package:antunes/widgets/playlist_cube.dart';
import 'package:antunes/widgets/playlist_page/empty_playlist_state.dart';
import 'package:antunes/widgets/playlist_page/playlist_header.dart';
import 'package:antunes/widgets/playlist_page/search_bar_section.dart';
import 'package:antunes/widgets/song_bar.dart';
import 'package:antunes/widgets/sort_chips.dart';
import 'package:antunes/widgets/spinner.dart';

enum PlaylistSortType { default_, title, artist }

class PlaylistPage extends StatefulWidget {
  const PlaylistPage({
    super.key,
    this.playlistId,
    this.playlistData,
    this.cubeIcon = FluentIcons.text_bullet_list_24_filled,
    this.isArtist = false,
  });

  final String? playlistId;
  final dynamic playlistData;
  final IconData cubeIcon;
  final bool isArtist;

  @override
  _PlaylistPageState createState() => _PlaylistPageState();
}

class _PlaylistPageState extends State<PlaylistPage> {
  dynamic _playlist;
  late final List<dynamic>
  _originalPlaylistList; // Keep original order separately

  late final playlistLikeStatus = ValueNotifier<bool>(
    isPlaylistAlreadyLiked(_resolvedPlaylistId),
  );
  bool playlistOfflineStatus = false;

  String? get _resolvedPlaylistId =>
      _playlist?['ytid']?.toString() ??
      widget.playlistData?['ytid']?.toString() ??
      widget.playlistId;

  // Sorting
  late PlaylistSortType _sortType = PlaylistSortType.values.firstWhere(
    (e) => e.name == playlistSortSetting,
    orElse: () => PlaylistSortType.default_,
  );

  // Search
  final ValueNotifier<String> _searchQueryNotifier = ValueNotifier('');
  late final TextEditingController _searchController;
  late final FocusNode _searchFocusNode;

  List<dynamic> _getSourceList(String searchQuery) {
    final list = _playlist?['list'] as List<dynamic>? ?? [];
    return filterSongsByQuery(list, searchQuery);
  }

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _searchFocusNode = FocusNode();
    userLikedPlaylists.addListener(_syncPlaylistLikeStatus);
    _initializePlaylist();
  }

  @override
  void dispose() {
    userLikedPlaylists.removeListener(_syncPlaylistLikeStatus);
    playlistLikeStatus.dispose();
    _searchController.dispose();
    _searchFocusNode.dispose();
    _searchQueryNotifier.dispose();
    super.dispose();
  }

  void _syncPlaylistLikeStatus() {
    final newStatus = isPlaylistAlreadyLiked(_resolvedPlaylistId);
    if (playlistLikeStatus.value != newStatus) {
      playlistLikeStatus.value = newStatus;
    }
  }

  Future<void> _initializePlaylist() async {
    try {
      final initialPlaylist = widget.playlistData;
      final resolvedId =
          initialPlaylist?['ytid']?.toString() ?? widget.playlistId;

      if (initialPlaylist != null) {
        _playlist = initialPlaylist;
        final playlistList = _playlist?['list'] as List?;
        if ((playlistList == null || playlistList.isEmpty) &&
            resolvedId != null) {
          _playlist =
              await getPlaylistInfoForWidget(
                resolvedId,
                isArtist: widget.isArtist,
              ) ??
              initialPlaylist;
        }
      } else {
        _playlist = await getPlaylistInfoForWidget(
          resolvedId,
          isArtist: widget.isArtist,
        );
      }

      if (_playlist != null && _playlist['list'] != null) {
        _originalPlaylistList = List<dynamic>.from(_playlist['list'] as List);
        _sortPlaylist(_sortType);
        _syncPlaylistLikeStatus();
        if (mounted) {
          setState(() {});
        }
      }
    } catch (e, stackTrace) {
      logger.log(
        'Error initializing playlist:',
        error: e,
        stackTrace: stackTrace,
      );
      if (mounted) {
        showToast(context, context.l10n!.error);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(FluentIcons.arrow_left_24_regular),
          onPressed: () =>
              Navigator.pop(context, widget.playlistData == _playlist),
          tooltip: context.l10n!.back,
        ),
      ),
      body: _playlist != null
          ? CustomScrollView(
              slivers: [
                SliverToBoxAdapter(child: _buildHeaderSection()),
                if ((_playlist['list'] as List).isNotEmpty) ...[
                  ValueListenableBuilder<String>(
                    valueListenable: _searchQueryNotifier,
                    builder: (context, searchQuery, _) {
                      final sourceList = _getSourceList(searchQuery);
                      return SliverPadding(
                        padding: commonListViewBottomPadding,
                        sliver: SliverList.builder(
                          itemCount: sourceList.length,
                          itemBuilder: (context, index) {
                            final isRemovable =
                                _playlist['source'] == 'user-created';
                            return _buildSongListItem(
                              sourceList[index],
                              index,
                              isRemovable,
                            );
                          },
                        ),
                      );
                    },
                  ),
                ] else
                  EmptyPlaylistState(message: context.l10n!.noSongsInPlaylist),
                const SliverMiniPlayerBottomSpace(),
              ],
            )
          : SizedBox(
              height: MediaQuery.sizeOf(context).height - 100,
              child: const Spinner(),
            ),
    );
  }

  Widget _buildPlaylistImage() {
    final screenWidth = MediaQuery.sizeOf(context).width;
    final isLandscape = screenWidth > MediaQuery.sizeOf(context).height;
    return PlaylistCube(
      _playlist,
      size: isLandscape ? 250 : screenWidth / commonPlaylistArtworkDivision,
      cubeIcon: widget.cubeIcon,
      showTypeLabel: false,
    );
  }

  Widget _buildHeaderSection() {
    final songsLength = _playlist['list'].length;
    final isUserCreated = _playlist['source'] == 'user-created';
    final colorScheme = Theme.of(context).colorScheme;

    final hasSecondaryActions =
        (widget.playlistId != null && !isUserCreated && !offlineMode.value) ||
        !offlineMode.value ||
        isUserCreated;

    return Column(
      children: [
        PlaylistHeader(
          _buildPlaylistImage(),
          _playlist['title'],
          songsLength,
          isAlbum: _playlist['isAlbum'] == true,
        ),
        if (songsLength > 0) ...[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    icon: const Icon(FluentIcons.play_24_filled),
                    label: Text(context.l10n!.play),
                    onPressed: () => audioHandler.playPlaylistSong(
                      playlist: _playlist,
                      songIndex: 0,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: colorScheme.secondaryContainer,
                      foregroundColor: colorScheme.onSecondaryContainer,
                    ),
                    icon: const Icon(FluentIcons.arrow_shuffle_24_filled),
                    label: Text(context.l10n!.shuffle),
                    onPressed: () async {
                      final songs = _playlist['list'] as List? ?? [];
                      if (songs.isEmpty) return;
                      final shuffled = List<Map>.from(songs.whereType<Map>())
                        ..shuffle();
                      await audioHandler.addPlaylistToQueue(
                        shuffled,
                        replace: true,
                        startIndex: 0,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
        if (hasSecondaryActions) ...[
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            spacing: 5,
            children: [
              if (widget.playlistId != null &&
                  !isUserCreated &&
                  !offlineMode.value)
                _buildLikeButton(),
              if (!offlineMode.value) ...[
                _buildAddToPlaylistButton(),
                if (!isUserCreated) _buildSyncButton(),
              ],
              if (songsLength > 0) _buildDownloadButton(),
              if (isUserCreated) ...[_buildShareButton(), _buildEditButton()],
            ],
          ),
        ],
        if (songsLength > 1) ...[
          const SizedBox(height: 12),
          SortChips<PlaylistSortType>(
            currentSortType: _sortType,
            sortTypes: PlaylistSortType.values,
            sortTypeToString: _getSortTypeDisplayText,
            onSelected: (type) {
              setState(() {
                _sortType = type;
                addOrUpdateData<String>(
                  'settings',
                  'playlistSortType',
                  type.name,
                );
                playlistSortSetting = type.name;
                _sortPlaylist(type);
              });
            },
          ),
        ],
        if (songsLength > 0) ...[
          const SizedBox(height: 16),
          SearchBarSection(
            controller: _searchController,
            focusNode: _searchFocusNode,
            onSearchChanged: (value) => _searchQueryNotifier.value = value,
            labelText: context.l10n!.search,
          ),
        ],
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildShareButton() {
    return IconButton.filledTonal(
      icon: const Icon(FluentIcons.share_24_regular),
      iconSize: 24,
      onPressed: () async {
        try {
          final encodedPlaylist = PlaylistSharingService.encodePlaylist(
            _playlist,
          );
          final url = 'antunes://playlist/custom/$encodedPlaylist';
          await Clipboard.setData(ClipboardData(text: url));
          if (mounted) {
            showToast(context, context.l10n!.linkCopied);
          }
        } catch (e, stackTrace) {
          logger.log(
            'Error sharing playlist',
            error: e,
            stackTrace: stackTrace,
          );
          if (mounted) {
            showToast(context, context.l10n!.error);
          }
        }
      },
      tooltip: context.l10n!.share,
    );
  }

  Widget _buildLikeButton() {
    return ValueListenableBuilder<bool>(
      valueListenable: playlistLikeStatus,
      builder: (_, value, __) {
        final icon = value
            ? FluentIcons.heart_24_filled
            : FluentIcons.heart_24_regular;

        return value
            ? IconButton.filled(
                icon: Icon(icon),
                iconSize: 24,
                onPressed: () {
                  playlistLikeStatus.value = !playlistLikeStatus.value;
                  unawaited(
                    updatePlaylistLikeStatus(
                      _playlist['ytid'],
                      playlistLikeStatus.value,
                      playlistData: _playlist,
                    ),
                  );
                },
                tooltip: context.l10n!.removeFromLikedSongs,
              )
            : IconButton.filledTonal(
                icon: Icon(icon),
                iconSize: 24,
                onPressed: () {
                  playlistLikeStatus.value = !playlistLikeStatus.value;
                  unawaited(
                    updatePlaylistLikeStatus(
                      _playlist['ytid'],
                      playlistLikeStatus.value,
                      playlistData: _playlist,
                    ),
                  );
                },
                tooltip: context.l10n!.addToLikedSongs,
              );
      },
    );
  }

  Widget _buildSyncButton() {
    return IconButton.filledTonal(
      icon: const Icon(FluentIcons.arrow_sync_24_filled),
      iconSize: 24,
      onPressed: _handleSyncPlaylist,
      tooltip: context.l10n!.update,
    );
  }

  Widget _buildAddToPlaylistButton() {
    return IconButton.filledTonal(
      icon: const Icon(FluentIcons.album_add_24_regular),
      iconSize: 24,
      onPressed: _handleAddFullPlaylistToPlaylist,
      tooltip: context.l10n!.addToPlaylist,
    );
  }

  void _handleAddFullPlaylistToPlaylist() {
    if (_playlist != null && _playlist['list'] != null) {
      final List<dynamic> tracks = _playlist['list'];
      if (tracks.isEmpty) {
        showToast(context, context.l10n!.noSongsInPlaylist);
        return;
      }
      showAddToPlaylistDialog(context, songs: tracks);
    } else {
      showToast(context, context.l10n!.loading);
    }
  }

  Widget _buildEditButton() {
    return IconButton.filledTonal(
      icon: const Icon(FluentIcons.edit_24_filled),
      iconSize: 24,
      onPressed: () async {
        final result = await showDialog<Map?>(
          context: context,
          builder: (context) => EditPlaylistDialog(playlistData: _playlist),
        );

        if (result != null) {
          final resolvedPlaylistYtid =
              _playlist['ytid']?.toString() ?? widget.playlistId;
          if (resolvedPlaylistYtid == null ||
              resolvedPlaylistYtid.isEmpty ||
              resolvedPlaylistYtid == 'null') {
            showToast(context, context.l10n!.error);
            return;
          }

          final updatedPlaylist = {
            ..._playlist,
            ...result,
            'ytid': resolvedPlaylistYtid,
            'source': _playlist['source'] ?? result['source'],
            'list': result['list'] ?? _playlist['list'],
          };

          // Search root list first, then inside folders.
          final rootIndex = userCustomPlaylists.value.indexWhere(
            (p) => p['ytid'] == resolvedPlaylistYtid,
          );

          if (rootIndex != -1) {
            final updatedPlaylists = List<Map>.from(userCustomPlaylists.value);
            updatedPlaylists[rootIndex] = updatedPlaylist;
            userCustomPlaylists.value = updatedPlaylists;
            unawaited(
              addOrUpdateData<List>(
                'user',
                'customPlaylists',
                userCustomPlaylists.value,
              ),
            );
          } else {
            // Playlist lives inside a folder - update it there.
            final updatedFolders = List<Map>.from(userPlaylistFolders.value);
            for (final folder in updatedFolders) {
              final folderPlaylists = List<Map>.from(
                folder['playlists'] as List? ?? [],
              );
              final fi = folderPlaylists.indexWhere(
                (p) => p['ytid'] == resolvedPlaylistYtid,
              );
              if (fi != -1) {
                folderPlaylists[fi] = updatedPlaylist;
                folder['playlists'] = folderPlaylists;
                break;
              }
            }
            userPlaylistFolders.value = updatedFolders;
            unawaited(
              addOrUpdateData<List>(
                'user',
                'playlistFolders',
                userPlaylistFolders.value,
              ),
            );
          }

          // Update offline playlist if it exists
          unawaited(syncOfflinePlaylistMetadata(updatedPlaylist));

          setState(() => _playlist = updatedPlaylist);
          showToast(context, context.l10n!.playlistUpdated);
        }
      },
      tooltip: context.l10n!.editPlaylist,
    );
  }

  Widget _buildDownloadButton() {
    final playlistId = _playlist?['ytid']?.toString() ?? widget.playlistId;

    if (playlistId == null || playlistId.isEmpty) {
      return const SizedBox.shrink();
    }

    return ValueListenableBuilder<List>(
      valueListenable: userOfflineSongs,
      builder: (context, _, __) {
        return ValueListenableBuilder<List>(
          valueListenable: offlinePlaylistService.offlinePlaylists,
          builder: (context, offlinePlaylists, _) {
            final playlistSongs = _playlist?['list'] as List? ?? [];
            playlistOfflineStatus = isPlaylistFullyOffline(playlistSongs);

            if (playlistOfflineStatus) {
              return IconButton.filled(
                icon: Icon(
                  FluentIcons.arrow_download_off_24_filled,
                  color: Theme.of(context).colorScheme.onPrimary,
                ),
                iconSize: 24,
                onPressed: () => _showRemoveOfflineDialog(playlistId),
                tooltip: context.l10n!.removeOffline,
              );
            }

            return ValueListenableBuilder<DownloadProgress>(
              valueListenable: offlinePlaylistService.getProgressNotifier(
                playlistId,
              ),
              builder: (context, progress, _) {
                final isDownloading = offlinePlaylistService
                    .isPlaylistDownloading(playlistId);

                if (isDownloading) {
                  return SizedBox(
                    width: 48,
                    height: 48,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        SizedBox(
                          width: 40,
                          height: 40,
                          child: CircularProgressIndicator(
                            value: progress.isCancelled
                                ? null
                                : progress.progress,
                            strokeWidth: 3,
                            backgroundColor: Theme.of(
                              context,
                            ).colorScheme.primaryContainer,
                          ),
                        ),
                        if (!progress.isCancelled)
                          IconButton(
                            icon: const Icon(
                              FluentIcons.dismiss_24_filled,
                              size: 16,
                            ),
                            onPressed: () => offlinePlaylistService
                                .cancelDownload(context, playlistId),
                            tooltip: context.l10n!.cancel,
                          ),
                      ],
                    ),
                  );
                }

                if (offlineMode.value) {
                  return const SizedBox.shrink();
                }

                return IconButton.filledTonal(
                  icon: const Icon(FluentIcons.arrow_download_24_filled),
                  iconSize: 24,
                  onPressed: () => offlinePlaylistService.downloadPlaylist(
                    context,
                    _playlist,
                  ),
                  tooltip: context.l10n!.downloadPlaylist,
                );
              },
            );
          },
        );
      },
    );
  }

  void _showRemoveOfflineDialog(String playlistId) =>
      showRemoveOfflinePlaylistDialog(context, playlistId);

  void _handleSyncPlaylist() async {
    final playlistId = _playlist?['ytid']?.toString();
    if (playlistId == null || playlistId.isEmpty) return;

    if (offlinePlaylistService.isPlaylistDownloaded(playlistId)) {
      if (mounted) {
        showToast(context, context.l10n!.removeOffline);
      }
      return;
    }

    final updated = await updatePlaylistList(context, playlistId);
    if (updated != null && mounted) {
      setState(() {
        _playlist = updated;
        if (_playlist['list'] != null) {
          _originalPlaylistList = List<dynamic>.from(_playlist['list'] as List);
        }
      });
    }
  }

  void _updateSongsListOnRemove(int indexOfRemovedSong, dynamic songToRemove) {
    _originalPlaylistList.removeWhere((s) => s['ytid'] == songToRemove['ytid']);
    final playlistId = _playlist['ytid'];
    if (mounted) {
      setState(() {});
      showToastWithButton(
        context,
        context.l10n!.songRemoved,
        context.l10n!.undo.toUpperCase(),
        () {
          addSongInCustomPlaylist(
            context,
            playlistId,
            songToRemove,
            indexToInsert: indexOfRemovedSong,
          );
          if (mounted) setState(() {});
        },
      );
    } else {
      logger.log(
        '(_updateSongsListOnRemove): Widget not mounted, cannot show undo toast.',
      );
    }
  }

  String _getSortTypeDisplayText(PlaylistSortType type) {
    switch (type) {
      case PlaylistSortType.default_:
        return context.l10n!.default_;
      case PlaylistSortType.title:
        return context.l10n!.name;
      case PlaylistSortType.artist:
        return context.l10n!.artist;
    }
  }

  void _sortPlaylist(PlaylistSortType type) {
    if (_playlist == null || _playlist['list'] == null) return;

    switch (type) {
      case PlaylistSortType.default_:
        // Restore original order from backup
        _playlist['list'] = List<dynamic>.from(_originalPlaylistList);
        break;
      case PlaylistSortType.title:
        final playlist = List<dynamic>.from(_playlist['list']);
        sortSongsByKey(playlist, 'title');
        _playlist['list'] = playlist;
        break;
      case PlaylistSortType.artist:
        final playlist = List<dynamic>.from(_playlist['list']);
        sortSongsByKey(playlist, 'artist');
        _playlist['list'] = playlist;
        break;
    }
  }

  Widget _buildSongListItem(dynamic song, int index, bool isRemovable) {
    final sourceList = _getSourceList(_searchQueryNotifier.value);
    final totalItems = sourceList.length;
    final borderRadius = getItemBorderRadius(index, totalItems);
    final isUserCreatedPlaylist = _playlist?['source'] == 'user-created';
    final playlistId = isUserCreatedPlaylist ? _playlist!['ytid'] : null;
    final isSearching = _searchQueryNotifier.value.isNotEmpty;
    final fullIndex = isSearching
        ? PlaylistUtils.findSongIndexByYtid(_playlist, song['ytid'])
        : index;

    if (isSearching && fullIndex == -1) {
      logger.log('Warning: Song ${song['ytid']} not found in full playlist');
    }

    return SongBar(
      song,
      true,
      key: listItemKey('playlist_song', index, song),
      onRemove: (isRemovable && !isSearching)
          ? () {
              if (removeSongFromPlaylist(
                _playlist,
                song,
                removeOneAtIndex: index,
              )) {
                _updateSongsListOnRemove(index, song);
              }
            }
          : null,
      onPlay: () {
        audioHandler.playPlaylistSong(
          playlist: _playlist,
          songIndex: fullIndex != -1 ? fullIndex : index,
        );
      },
      borderRadius: borderRadius,
      playlistId: playlistId,
      onRenamed: () => setState(() {}),
    );
  }
}
