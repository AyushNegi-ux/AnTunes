// ignore_for_file: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member

/*
 *     Copyright (C) 2026 Valeri Gokadze
 *
 *     Musify is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     Musify is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 *
 *     For more information about Musify, including how to contribute,
 *     please visit: https://github.com/gokadzev/Musify
 */

import 'dart:async';
import 'dart:collection';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:antunes/extensions/l10n.dart';
import 'package:antunes/main.dart';
import 'package:antunes/services/common_services.dart';
import 'package:antunes/services/data_manager.dart';
import 'package:antunes/services/io_service.dart';
import 'package:antunes/services/playlists_manager.dart';
import 'package:antunes/utilities/flutter_toast.dart';

class OfflinePlaylistService {
  factory OfflinePlaylistService() => _instance;
  OfflinePlaylistService._internal();
  static final OfflinePlaylistService _instance =
      OfflinePlaylistService._internal();

  // Playlist download state notifiers
  final Map<String, ValueNotifier<DownloadProgress>> downloadProgressNotifiers =
      {};
  final List<String> activeDownloads = [];

  // List of playlists that are fully available offline
  final offlinePlaylists = ValueNotifier<List<dynamic>>(
    Hive.box('userNoBackup').get('offlinePlaylists', defaultValue: []),
  );

  ValueNotifier<DownloadProgress> getProgressNotifier(String playlistId) {
    if (!downloadProgressNotifiers.containsKey(playlistId)) {
      downloadProgressNotifiers[playlistId] = ValueNotifier<DownloadProgress>(
        DownloadProgress(total: 0),
      );
    }
    return downloadProgressNotifiers[playlistId]!;
  }

  bool isPlaylistDownloaded(String playlistId) {
    return offlinePlaylists.value.any(
      (playlist) => playlist['ytid'] == playlistId,
    );
  }

  bool isPlaylistDownloading(String playlistId) {
    return activeDownloads.contains(playlistId);
  }

  Future<void> downloadPlaylist(BuildContext context, Map playlist) async {
    final playlistId = playlist['ytid'] as String? ?? playlist['title'];

    if (playlistId == null || playlistId.isEmpty) {
      showToast(context, context.l10n!.error);
      return;
    }

    // Check if already downloading
    if (isPlaylistDownloading(playlistId)) {
      showToast(context, context.l10n!.alreadyDownloading);
      return;
    }

    // Initialize download state
    final songsList = playlist['list'] as List<dynamic>? ?? [];
    if (songsList.isEmpty) {
      showToast(context, context.l10n!.playlistEmpty);
      return;
    }

    // Set up progress tracking
    final progressNotifier = getProgressNotifier(playlistId)
      ..value = DownloadProgress(total: songsList.length);
    activeDownloads.add(playlistId);

    try {
      final songQueue = Queue<dynamic>.from(songsList);
      const maxConcurrent = 3;
      final workerCount = songsList.length < maxConcurrent
          ? songsList.length
          : maxConcurrent;

      await Future.wait([
        for (var i = 0; i < workerCount; i++)
          _processDownloadQueue(songQueue, progressNotifier),
      ]).timeout(
        Duration(minutes: songsList.length * 2),
        onTimeout: () {
          logger.log('Download timeout for playlist $playlistId');
          progressNotifier.value.isCancelled = true;
          progressNotifier.notifyListeners();
          return <void>[];
        },
      );

      // Handle completion
      await _handleDownloadCompletion(
        context,
        playlistId,
        playlist,
        progressNotifier,
      );
    } catch (e, stackTrace) {
      logger.log(
        'Error during playlist download',
        error: e,
        stackTrace: stackTrace,
      );
      activeDownloads.remove(playlistId);
      cleanupProgressNotifier(playlistId);
      if (context.mounted) {
        showToast(context, '${context.l10n!.error}: $e');
      }
    }
  }

  Future<void> _handleDownloadCompletion(
    BuildContext context,
    String playlistId,
    Map playlist,
    ValueNotifier<DownloadProgress> progressNotifier,
  ) async {
    try {
      // Remove from active downloads
      activeDownloads.remove(playlistId);

      final songsList = playlist['list'] as List<dynamic>;

      // Only add to offline playlists if not cancelled and most songs succeeded
      if (!progressNotifier.value.isCancelled &&
          progressNotifier.value.completed > progressNotifier.value.failed) {
        // Create an offline version of the playlist
        final offlinePlaylist = {
          'ytid': playlistId,
          'title': playlist['title'],
          'image': playlist['image'],
          'source': playlist['source'],
          'list': songsList,
          'downloadedAt': DateTime.now().millisecondsSinceEpoch,
        };

        // Add to offline playlists
        final updatedPlaylists = List<dynamic>.from(offlinePlaylists.value);

        final existingIndex = updatedPlaylists.indexWhere(
          (p) => p['ytid'] == playlistId,
        );

        if (existingIndex != -1) {
          updatedPlaylists[existingIndex] = offlinePlaylist;
        } else {
          updatedPlaylists.add(offlinePlaylist);
        }

        offlinePlaylists.value = updatedPlaylists;
        unawaited(
          addOrUpdateData<List>(
            'userNoBackup',
            'offlinePlaylists',
            offlinePlaylists.value,
          ),
        );

        if (context.mounted) {
          showToast(
            context,
            '${context.l10n!.playlistDownloaded}: ${progressNotifier.value.completed}/${songsList.length}',
          );
        }
      } else if (!progressNotifier.value.isCancelled) {
        // Cancelled toast is shown by cancelDownload, only show failure toast here.
        if (context.mounted) {
          showToast(
            context,
            '${context.l10n!.downloadFailed}: ${progressNotifier.value.failed}/${songsList.length}',
          );
        }
      }

      // Clean up the progress notifier now that the download is fully done.
      cleanupProgressNotifier(playlistId);
    } catch (e, stackTrace) {
      logger.log(
        'Error handling download completion',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }

  Future<void> cancelDownload(BuildContext context, String playlistId) async {
    if (!isPlaylistDownloading(playlistId)) return;

    try {
      final progressNotifier = getProgressNotifier(playlistId);
      progressNotifier.value.isCancelled = true;
      progressNotifier.notifyListeners();

      // Immediate visual feedback
      showToast(context, context.l10n!.cancellingDownload);

      const maxWaitTime = Duration(seconds: 30);
      final startTime = DateTime.now();

      // Wait for the ongoing tasks to complete with timeout
      while (activeDownloads.contains(playlistId)) {
        await Future.delayed(const Duration(milliseconds: 100));

        if (DateTime.now().difference(startTime) > maxWaitTime) {
          logger.log('Timeout waiting for download cancellation');
          activeDownloads.remove(playlistId);
          cleanupProgressNotifier(playlistId);
          break;
        }
      }

      showToast(context, context.l10n!.downloadCancelled);
    } catch (e, stackTrace) {
      logger.log('Error cancelling download', error: e, stackTrace: stackTrace);
      // Force remove from active downloads and cleanup on error
      activeDownloads.remove(playlistId);
      cleanupProgressNotifier(playlistId);
    }
  }

  Future<void> removeOfflinePlaylist(String playlistId) async {
    try {
      final normalizedPlaylistId = playlistId.trim();
      if (normalizedPlaylistId.isEmpty) {
        logger.log('Invalid playlistId for removal');
        return;
      }

      // Find the playlist
      final playlistIndex = offlinePlaylists.value.indexWhere(
        (playlist) =>
            playlist is Map &&
            playlist['ytid']?.toString() == normalizedPlaylistId,
      );

      if (playlistIndex == -1) {
        logger.log('Playlist not found for removal: $normalizedPlaylistId');
        return;
      }

      final playlist = offlinePlaylists.value[playlistIndex] as Map;

      // Get songs that are only in this playlist
      final songsInPlaylist = playlist['list'] as List<dynamic>? ?? [];
      for (final song in songsInPlaylist) {
        try {
          final songId = song['ytid'] as String?;

          if (songId == null || songId.isEmpty) {
            continue;
          }

          // Check if this song is used in other offline playlists
          final isUsedInOtherPlaylists = offlinePlaylists.value
              .where(
                (p) =>
                    p is Map && p['ytid']?.toString() != normalizedPlaylistId,
              ) // Exclude current playlist
              .any((p) {
                final playlistSongs = p['list'] as List<dynamic>? ?? [];
                return playlistSongs.any((s) => s['ytid'] == songId);
              });

          // Also check if song is in user's liked songs or OTHER custom playlists
          final isInLikedSongs = userLikedSongsList.value.any(
            (s) => s['ytid'] == songId,
          );
          final isInOtherCustomPlaylists = getUserCustomPlaylists()
              .where((p) => p['ytid']?.toString() != normalizedPlaylistId)
              .any((p) {
                final customPlaylistSongs = p['list'] as List<dynamic>? ?? [];
                return customPlaylistSongs.any((s) => s['ytid'] == songId);
              });

          // Only remove if not used elsewhere
          if (!isUsedInOtherPlaylists &&
              !isInLikedSongs &&
              !isInOtherCustomPlaylists) {
            await removeSongFromOffline(songId);
          }
        } catch (e, stackTrace) {
          logger.log(
            'Error removing song from offline',
            error: e,
            stackTrace: stackTrace,
          );
        }
      }

      // Remove playlist from offline playlists
      final updatedPlaylists = List<dynamic>.from(offlinePlaylists.value)
        ..removeWhere(
          (p) => p is Map && p['ytid']?.toString() == normalizedPlaylistId,
        );
      offlinePlaylists.value = updatedPlaylists;
      unawaited(
        addOrUpdateData<List>(
          'userNoBackup',
          'offlinePlaylists',
          offlinePlaylists.value,
        ),
      );
    } catch (e, stackTrace) {
      logger.log(
        'Error removing offline playlist',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }

  Future<void> deleteAllDownloads() async {
    // Cancel all active downloads first and wait for them to stop
    final activeIds = List<String>.from(activeDownloads);
    for (final id in activeIds) {
      final notifier = downloadProgressNotifiers[id];
      if (notifier != null) {
        notifier.value.isCancelled = true;
        notifier.notifyListeners();
      }
    }

    const maxWaitTime = Duration(seconds: 30);
    final startTime = DateTime.now();
    while (activeDownloads.isNotEmpty) {
      if (DateTime.now().difference(startTime) > maxWaitTime) {
        logger.log('Timeout waiting for downloads to cancel before delete');
        activeDownloads.clear();
        break;
      }
      await Future.delayed(const Duration(milliseconds: 100));
    }

    try {
      final tracksDir = Directory('$applicationDirPath/${FilePaths.tracksDir}');
      final artworksDir = Directory(
        '$applicationDirPath/${FilePaths.artworksDir}',
      );

      if (await tracksDir.exists()) {
        await tracksDir.delete(recursive: true);
      }
      if (await artworksDir.exists()) {
        await artworksDir.delete(recursive: true);
      }

      await FilePaths.ensureDirectoriesExist();

      userOfflineSongs.value = [];

      offlinePlaylists.value = [];

      for (final notifier in downloadProgressNotifiers.values) {
        notifier.dispose();
      }
      downloadProgressNotifiers.clear();
      activeDownloads.clear();

      unawaited(addOrUpdateData<List>('userNoBackup', 'offlineSongs', []));
      unawaited(addOrUpdateData<List>('userNoBackup', 'offlinePlaylists', []));

      logger.log('All downloads deleted successfully');
    } catch (e, stackTrace) {
      logger.log(
        'Error deleting all downloads',
        error: e,
        stackTrace: stackTrace,
      );
      rethrow;
    }
  }

  void cleanupProgressNotifier(String playlistId) {
    try {
      if (downloadProgressNotifiers.containsKey(playlistId)) {
        final notifier = downloadProgressNotifiers[playlistId];
        notifier?.value = DownloadProgress(total: 0);
      }
    } catch (e, stackTrace) {
      logger.log(
        'Error cleaning up progress notifier',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }

  Future<void> _processDownloadQueue(
    Queue<dynamic> songQueue,
    ValueNotifier<DownloadProgress> progressNotifier,
  ) async {
    while (songQueue.isNotEmpty && !progressNotifier.value.isCancelled) {
      final song = songQueue.removeFirst();

      try {
        if (song == null ||
            song['ytid'] == null ||
            song['ytid'].toString().isEmpty) {
          logger.log('Invalid song data in playlist download');
          progressNotifier.value.failed++;
          progressNotifier.notifyListeners();
          continue;
        }

        // Skip if already offline
        if (isSongAlreadyOffline(song['ytid'])) {
          // Find the existing offline song to get the correct audioPath
          final offlineSong = getOfflineSongByYtid(song['ytid']);
          if (offlineSong.isNotEmpty) {
            // Update the song in the playlist with the correct offline properties
            song['audioPath'] = offlineSong['audioPath'];
            song['artworkPath'] = offlineSong['artworkPath'];
          }
          // Update progress
          progressNotifier.value.completed++;
          progressNotifier.notifyListeners();
        } else {
          final success = await makeSongOffline(song);
          if (success) {
            progressNotifier.value.completed++;
          } else {
            progressNotifier.value.failed++;
          }
          progressNotifier.notifyListeners();
        }
      } catch (e, stackTrace) {
        logger.log(
          'Failed to download song: ${song?['title']}',
          error: e,
          stackTrace: stackTrace,
        );
        progressNotifier.value.failed++;
        progressNotifier.notifyListeners();
      }
    }
  }
}

class DownloadProgress {
  DownloadProgress({
    required this.total,
    this.completed = 0,
    this.failed = 0,
    this.isCancelled = false,
  });

  final int total;
  int completed;
  int failed;
  bool isCancelled;

  double get progress {
    if (total <= 0) return 0;
    final totalProcessed = completed + failed;
    return totalProcessed > total ? 1.0 : totalProcessed / total;
  }

  @override
  String toString() {
    final percentage = (progress * 100).toStringAsFixed(1);
    return '$percentage% ($completed/$total)';
  }
}

// Global instance for easy access
final offlinePlaylistService = OfflinePlaylistService();
